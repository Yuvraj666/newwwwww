package com.cg.ibs.loanmgmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.util.dbUtil;

public class LOL {

	public static void main(String[] args) {
		System.out.println("heeloo");
		Connection connection = dbUtil.getConnection();
		String sql = "select * from loan where loan_number = '1000'";
		PreparedStatement statement;
		System.out.println("sdfsdf");
		try {
			statement = connection.prepareStatement(sql);
			LoanMaster loanMaster = new LoanMaster();
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				loanMaster.setLoanAmount(resultSet.getDouble(3));
				System.out.println(loanMaster.getLoanAmount());
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
