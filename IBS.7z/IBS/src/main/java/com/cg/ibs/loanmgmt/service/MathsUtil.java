package com.cg.ibs.loanmgmt.service;

public class MathsUtil {
	public int add(int a, int b)	{
		return a+b;
	}
}
